/**
 * 
 */
/**
 * 
 */
module FlappyBird {
	requires java.desktop;
}